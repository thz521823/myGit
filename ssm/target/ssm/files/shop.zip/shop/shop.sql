drop database if exists fiveplus;
create database fiveplus character set utf8 collate utf8_general_ci;
use fiveplus;


create table user (
    id INT(11) PRIMARY KEY AUTO_INCREMENT COMMENT 'id',
    username VARCHAR (255) UNIQUE COMMENT '用户名',
    password VARCHAR(255) COMMENT '密码',
    create_time DATETIME COMMENT '创建时间',
    update_time DATETIME COMMENT '更新时间',
    login_time DATETIME COMMENT '登陆时间',
    phone_num VARCHAR(50) COMMENT '手机号码',
    is_deleted INT(2) COMMENT '是否删除 0删除，1没删除',
    power INT(2) COMMENT '权限 0用户，1管理员',
    session_id VARCHAR (50) COMMENT 'sessionId'
)ENGINE=InnoDB DEFAULT CHARSET=utf8;

insert into user(username,password,create_time,update_time,phone_num,is_deleted,power) values('凌','123123',now(),now(),
'13861842595',0,1);

create table cgtype(
    id INT(11) PRIMARY KEY AUTO_INCREMENT COMMENT 'id',
    cgtype_name VARCHAR (255)  COMMENT '种类名',
    create_time DATETIME COMMENT '创建时间',
    update_time DATETIME COMMENT '更新时间',
    is_deleted INT(2) COMMENT '是否删除 0删除，1没删除'
)ENGINE=InnoDB DEFAULT CHARSET=utf8;

insert into cgtype (cgtype_name, create_time, update_time, is_deleted) values('羽绒',now(),now(),0);
insert into cgtype (cgtype_name, create_time, update_time, is_deleted) values('外套',now(),now(),0);
insert into cgtype (cgtype_name, create_time, update_time, is_deleted) values('连衣裙',now(),now(),0);
insert into cgtype (cgtype_name, create_time, update_time, is_deleted) values('衬衫',now(),now(),0);
insert into cgtype (cgtype_name, create_time, update_time, is_deleted) values('裤装',now(),now(),0);

create table products(
    id INT(11) PRIMARY KEY AUTO_INCREMENT COMMENT 'id',
    title VARCHAR(255) COMMENT '标题',
    display_price DECIMAL(10,2) COMMENT '展示价格',
    category_id INT(11) COMMENT '种类id',
    brind VARCHAR(50) COMMENT '品牌',
    attr_list VARCHAR(255) COMMENT '参数列表',
    state INT(2) COMMENT '状态 0下架，1上架',
     create_time DATETIME COMMENT '创建时间',
    update_time DATETIME COMMENT '更新时间',
    is_deleted INT(2) COMMENT '是否删除 0删除，1没删除',
    products_num VARCHAR(255) COMMENT '商品号',
    picture_id INT(11) COMMENT '图片id'
)ENGINE=InnoDB DEFAULT CHARSET=utf8;

insert into products (title, display_price, category_id, brind, attr_list, state, create_time, update_time, is_deleted, products_num, picture_id)
values('FIVE PLUS2019新款女冬装派克羽绒服女鹅绒中长款狐狸大毛领外套',995,1,'FIVE PLUS','{"品牌":"FIVE PLUS","尺码":["XS","S"],"风格":"简约","颜色":["灰粉红181","米白101"]}',1,
now(),now(),0,'fd10dc422c034c77b10f449af7d7e578',1);
insert into products (title, display_price, category_id, brind, attr_list, state, create_time, update_time, is_deleted, products_num, picture_id)
values('FIVE PLUS2019新款女冬装一粒扣西装女长袖开襟外套收腰撞色条纹',399,2,'FIVE PLUS','{"品牌":"FIVE PLUS","尺码":["XS","S"],"风格":"百搭","颜色":["杏色870","黑色090"]}',1,
now(),now(),0,'7b28932a8c4545f688b988eec12fd04c',2);
insert into products (title, display_price, category_id, brind, attr_list, state, create_time, update_time, is_deleted, products_num, picture_id)
values('FIVE PLUS2020新款女春装印花雪纺连衣裙两件套装喇叭袖高腰短裙',899,3,'FIVE PLUS','{"品牌":"FIVE PLUS","尺码":["XS","S"],"风格":"甜美","颜色":["浅杏880"]}',1,
now(),now(),0,'bdaaeee180b1492b859946fd52b0934a',3);
insert into products (title, display_price, category_id, brind, attr_list, state, create_time, update_time, is_deleted, products_num, picture_id)
values('FIVE PLUS2020新款女春装蝴蝶结长袖衬衫女宽松荷叶花边飘带衬衣',399,4,'FIVE PLUS','{"品牌":"FIVE PLUS","尺码":["XS","S"],"风格":"百搭","颜色":["杏色870"]}',1,
now(),now(),0,'f4ab21f41b4d491b9123b320e870d70a',4);
insert into products (title, display_price, category_id, brind, attr_list, state, create_time, update_time, is_deleted, products_num, picture_id)
values('FIVE PLUS2019新款女冬装宽松直筒针织裤女高腰阔腿长裤撞色条纹',399,5,'FIVE PLUS','{"品牌":"FIVE PLUS","尺码":["L","S"],"风格":"百搭","颜色":["黑色090","米白101"]}',1,
now(),now(),0,'2062b8b2ac7c4d9bb9a43a23da37df27',5);
insert into products (title, display_price, category_id, brind, attr_list, state, create_time, update_time, is_deleted, products_num, picture_id)
values('FIVE PLUS2020新款女春装欧根纱绣花衬衫女宽松短袖两件套头上衣',499,1,'FIVE PLUS','{"品牌":"FIVE PLUS","尺码":["XS","S"],"风格":"百搭","颜色":["杏色870","浅粉113"]}',1,
now(),now(),0,'4cf4307d3919481b80aaff4bb26c84fa',6);

create table product (
    id INT(11) PRIMARY KEY AUTO_INCREMENT COMMENT 'id',
    products_id INT(11) COMMENT 'products id',
    stock INT(11) COMMENT '库存',
    product_index VARCHAR (255) COMMENT '组合索引',
    own_spec VARCHAR (255) COMMENT '组合',
    price DECIMAL (10,2) COMMENT '价格',
    create_time DATETIME COMMENT '创建时间',
    update_time DATETIME COMMENT '更新时间',
    is_deleted INT(2) COMMENT '是否删除 0删除，1没删除'
)ENGINE=InnoDB DEFAULT CHARSET=utf8;

insert into product(products_id, stock, product_index, own_spec, price, create_time, update_time, is_deleted) values (1,11,'0-0','尺码:XS, 颜色:灰粉红181',995,now(),now(),0);
insert into product(products_id, stock, product_index, own_spec, price, create_time, update_time, is_deleted) values (1,10,'0-1','尺码:XS, 颜色:米白101',995,now(),now(),0);
insert into product(products_id, stock, product_index, own_spec, price, create_time, update_time, is_deleted) values (1,9,'1-0','尺码:S, 颜色:灰粉红181',995,now(),now(),0);
insert into product(products_id, stock, product_index, own_spec, price, create_time, update_time, is_deleted) values (1,21,'1-1','尺码:S, 颜色:米白101',995,now(),now(),0);
insert into product(products_id, stock, product_index, own_spec, price, create_time, update_time, is_deleted) values (2,9,'0-0','尺码:XS, 颜色:杏色870',399,now(),now(),0);
insert into product(products_id, stock, product_index, own_spec, price, create_time, update_time, is_deleted) values (2,14,'0-1','尺码:XS, 颜色:黑色090',399,now(),now(),0);
insert into product(products_id, stock, product_index, own_spec, price, create_time, update_time, is_deleted) values (2,22,'1-0','尺码:S, 颜色:杏色870',399,now(),now(),0);
insert into product(products_id, stock, product_index, own_spec, price, create_time, update_time, is_deleted) values (2,12,'1-1','尺码:S, 颜色:黑色090',399,now(),now(),0);
insert into product(products_id, stock, product_index, own_spec, price, create_time, update_time, is_deleted) values (3,19,'0-0','尺码:XS, 颜色:浅杏880',899,now(),now(),0);
insert into product(products_id, stock, product_index, own_spec, price, create_time, update_time, is_deleted) values (3,19,'1-0','尺码:S, 颜色:浅杏880',899,now(),now(),0);
insert into product(products_id, stock, product_index, own_spec, price, create_time, update_time, is_deleted) values (4,12,'0-0','尺码:XS, 颜色:杏色870',399,now(),now(),0);
insert into product(products_id, stock, product_index, own_spec, price, create_time, update_time, is_deleted) values (4,22,'1-0','尺码:S, 颜色:杏色870',399,now(),now(),0);
insert into product(products_id, stock, product_index, own_spec, price, create_time, update_time, is_deleted) values (5,11,'0-0','尺码:L, 颜色:黑色090',399,now(),now(),0);
insert into product(products_id, stock, product_index, own_spec, price, create_time, update_time, is_deleted) values (5,22,'0-1','尺码:L, 颜色:米白101',399,now(),now(),0);
insert into product(products_id, stock, product_index, own_spec, price, create_time, update_time, is_deleted) values (5,13,'1-0','尺码:S, 颜色:黑色090',399,now(),now(),0);
insert into product(products_id, stock, product_index, own_spec, price, create_time, update_time, is_deleted) values (5,14,'1-1','尺码:S, 颜色:米白101',399,now(),now(),0);
insert into product(products_id, stock, product_index, own_spec, price, create_time, update_time, is_deleted) values (6,11,'0-0','尺码:XS, 颜色:杏色870',499,now(),now(),0);
insert into product(products_id, stock, product_index, own_spec, price, create_time, update_time, is_deleted) values (6,22,'0-1','尺码:XS, 颜色:浅粉113',499,now(),now(),0);
insert into product(products_id, stock, product_index, own_spec, price, create_time, update_time, is_deleted) values (6,17,'1-0','尺码:S, 颜色:杏色870',499,now(),now(),0);
insert into product(products_id, stock, product_index, own_spec, price, create_time, update_time, is_deleted) values (6,22,'1-1','尺码:S, 颜色:浅粉113',499,now(),now(),0);

create table picture(
    id INT(11) PRIMARY KEY AUTO_INCREMENT COMMENT 'id',
    dis_pic VARCHAR (255) COMMENT '展示图片',
    det_a VARCHAR (255) COMMENT '大图a',
    det_b VARCHAR (255) COMMENT '大图b',
    det_c VARCHAR (255) COMMENT '大图c',
   create_time DATETIME COMMENT '创建时间',
    update_time DATETIME COMMENT '更新时间',
    is_deleted INT(2) COMMENT '是否删除 0删除，1没删除'
)ENGINE=InnoDB DEFAULT CHARSET=utf8;

insert into picture (dis_pic, det_a, det_b, det_c, create_time, update_time, is_deleted) values ('img/productImg/dis001.jpg','img/productImg/det001a.jpg',
'img/productImg/det001b.jpg','img/productImg/det001c.jpg',now(),now(),0);
insert into picture (dis_pic, det_a, det_b, det_c, create_time, update_time, is_deleted) values ('img/productImg/dis002.jpg','img/productImg/det002a.jpg',
'img/productImg/det002b.jpg','img/productImg/det002c.jpg',now(),now(),0);
insert into picture (dis_pic, det_a, det_b, det_c, create_time, update_time, is_deleted) values ('img/productImg/dis003.jpg','img/productImg/det003a.jpg',
'img/productImg/det003b.jpg','img/productImg/det003c.jpg',now(),now(),0);
insert into picture (dis_pic, det_a, det_b, det_c, create_time, update_time, is_deleted) values ('img/productImg/dis004.jpg','img/productImg/det004a.jpg',
'img/productImg/det004b.jpg','img/productImg/det004c.jpg',now(),now(),0);
insert into picture (dis_pic, det_a, det_b, det_c, create_time, update_time, is_deleted) values ('img/productImg/dis005.jpg','img/productImg/det0015.jpg',
'img/productImg/det005b.jpg','img/productImg/det005c.jpg',now(),now(),0);
insert into picture (dis_pic, det_a, det_b, det_c, create_time, update_time, is_deleted) values ('img/productImg/dis006.jpg','img/productImg/det006a.jpg',
'img/productImg/det006b.jpg','img/productImg/det006c.jpg',now(),now(),0);

create table orders (
     id INT(11) PRIMARY KEY AUTO_INCREMENT COMMENT 'id',
     order_num VARCHAR (255) COMMENT '订单号',
     product_id INT(11) COMMENT 'product id',
     total_price DECIMAL(10,2) COMMENT '总价',
     num INT(11) COMMENT '数量',
    receive_id INT(11) COMMENT '收货id',
    state INT(2) COMMENT '订单状态 0未发货，1已发货，2交易成功',
   create_time DATETIME COMMENT '创建时间',
    update_time DATETIME COMMENT '更新时间',
    is_deleted INT(2) COMMENT '是否删除 0删除，1没删除'
)ENGINE=InnoDB DEFAULT CHARSET=utf8;

create table  receiver(
    id INT(11) PRIMARY KEY AUTO_INCREMENT COMMENT 'id',
    address VARCHAR (255) COMMENT '地址',
    rec_name VARCHAR (50) COMMENT '收货人姓名',
    phone_num VARCHAR (50) COMMENT '手机号',
    user_id INT(11) COMMENT 'user id',
  create_time DATETIME COMMENT '创建时间',
    update_time DATETIME COMMENT '更新时间',
    is_deleted INT(2) COMMENT '是否删除 0删除，1没删除'
)ENGINE=InnoDB DEFAULT CHARSET=utf8;

create table comment (
    id INT(11) PRIMARY KEY AUTO_INCREMENT COMMENT 'id',
    com_content TEXT COMMENT '评价内容',
    user_id INT(11) COMMENT 'user id',
    products_id INT(11) COMMENT 'products id',
create_time DATETIME COMMENT '创建时间',
    update_time DATETIME COMMENT '更新时间',
    is_deleted INT(2) COMMENT '是否删除 0删除，1没删除'
)ENGINE=InnoDB DEFAULT CHARSET=utf8;