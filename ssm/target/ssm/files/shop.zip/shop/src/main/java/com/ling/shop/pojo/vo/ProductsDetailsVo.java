package com.ling.shop.pojo.vo;

import lombok.Data;

@Data
public class ProductsDetailsVo {
    private String productsId;
    private String title;
    private Double price;
    private String attrList;
    private String detA;
    private String detB;
    private String detC;
    private String allStock;
    private String brind;
    private String productsNum;
}
