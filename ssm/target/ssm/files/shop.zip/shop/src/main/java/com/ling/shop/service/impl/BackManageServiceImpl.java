package com.ling.shop.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.ling.shop.dao.IBackManageDao;
import com.ling.shop.dao.IProductsDao;
import com.ling.shop.pojo.common.BusinessException;
import com.ling.shop.pojo.po.*;
import com.ling.shop.pojo.vo.BackOrderVo;
import com.ling.shop.pojo.vo.CommentVo;
import com.ling.shop.service.IBackManageService;
import com.ling.shop.service.IPersonalMsgService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class BackManageServiceImpl implements IBackManageService {
    @Autowired
    IBackManageDao iBackManageDao;
    @Autowired
    IProductsDao iProductsDao;

    //查询所有用户
    @Override
    public PageInfo<User> findAllUsers(String pageNum) {
        int pageN = 1;
        if (pageNum != null) {
            pageN = Integer.parseInt(pageNum);
        }
        PageHelper.startPage(pageN, 6);
        List<User> list = iBackManageDao.findAllUsers();
        if (list == null) {
            throw new BusinessException("操作失败！");
        } else {
            PageInfo<User> pageInfo = new PageInfo<User>(list);

            return pageInfo;

        }
    }

    //恢复，注销
    @Override
    public boolean updateIsDeleted(String isDeleted, String id) {
        if (iBackManageDao.updateUserIsDeleted(isDeleted, id)) {
            return iBackManageDao.updateUserIsDeleted(isDeleted, id);
        } else {
            throw new BusinessException("操作失败！");
        }
    }

    //查询所有商品
    @Override
    public PageInfo<Products> getAllpros(String pageNum) {
        if (pageNum == null) {
            pageNum = "1";
        }
        PageHelper.startPage(Integer.parseInt(pageNum), 3);
        List<Products> list = iBackManageDao.getAllpros();
        if (list == null) {
            throw new BusinessException("操作失败！");
        } else {
            PageInfo<Products> pageInfo = new PageInfo<>(list);
            return pageInfo;
        }
    }

    //查询所有分类
    @Override
    public PageInfo<Cgtype> getAllCategory(String catePageNum) {
        int pageNum = 1;
        if (catePageNum != null) {
            pageNum = Integer.parseInt(catePageNum);
        }
        PageHelper.startPage(pageNum, 6);
        List<Cgtype> list = iProductsDao.getCategory();
        if (list == null) {
            throw new BusinessException("操作失败！");
        } else {
            PageInfo<Cgtype> pageInfo = new PageInfo<>(list);
            return pageInfo;
        }
    }

    //增加分类
    @Override
    public int addCategory(String categoryName) {
        int num = iBackManageDao.addCategory(categoryName);
        if (num > 0) {
            return num;
        } else {
            throw new BusinessException("操作失败！");
        }

    }


    //删除分类
    @Override
    public int isDeletedCate(String id) {
        int num = iBackManageDao.isDeletedCate(id);
        if (num > 0) {
            return num;
        } else {
            throw new BusinessException("操作失败！");
        }
    }

    //查询所有图片
    @Override
    public PageInfo<Picture> getAllpics(String picPageNum) {
        int pageNum = 1;
        if (picPageNum != null) {
            pageNum = Integer.parseInt(picPageNum);
        }
        PageHelper.startPage(pageNum, 6);
        List<Picture> list = iBackManageDao.getAllpics();
        if (list == null) {
            throw new BusinessException("操作失败！");
        } else {
            PageInfo<Picture> pageInfo = new PageInfo<>(list);
            return pageInfo;
        }
    }

    //增加商品
    @Override
    public int addPros(Products products) {
        int num = iBackManageDao.addPros(products);
        if (num > 0) {
            return num;
        } else {
            throw new BusinessException("操作失败！");
        }
    }

    //删除商品
    @Override
    public int prosIsDeleted(String id) {
        int num = iBackManageDao.prosIsDeleted(id);
        if (num > 0) {
            return num;
        } else {
            throw new BusinessException("操作失败！");
        }
    }

    //修改商品
    public int updatePros(Products products) {
        int num = iBackManageDao.updatePros(products);
        if (num > 0) {
            return num;
        } else {
            throw new BusinessException("操作失败！");
        }
    }

    //获取相关库存
    @Override
    public List<Product> getProduct(String productsId) {
        List<Product> list = iBackManageDao.getProduct(productsId);
        if (list == null) {
            throw new BusinessException("操作失败！");
        } else {
            return list;
        }
    }
//增加商品
    @Override
    public int addProduct(Product product) {
         int num = iBackManageDao.addProduct(product);
         if(num>0){
             return num;
         }else{
             throw new BusinessException("操作失败！");
         }
    }
//删除商品
    @Override
    public int proIsDeleted(String id) {
        int num = iBackManageDao.proIsDeleted(id);
        if(num>0){
            return  num;
        }else{
            throw new BusinessException("操作失败！");
        }
    }
//更新商品
    @Override
    public int updatePro(Product product) {
        int num = iBackManageDao.updatePro(product);
        if(num>0){
            return num;
        }else{
            throw new BusinessException("操作失败！");
        }
    }
//增加图片
    @Override
    public int addPic(Picture picture) {
        int num = iBackManageDao.addPic(picture);
        if(num>0){
            return num;
        }else{
            throw new BusinessException("操作失败！");
        }
    }

    @Override
    public int pisIsDeleted(String id) {
        int num = iBackManageDao.picIsDeleted(id);
        if(num>0){
            return num;
        }else{
            throw new BusinessException("操作失败！");
        }
    }
    //查询所有订单
    @Override
    public PageInfo<BackOrderVo> queryBackAllOrders(Integer pageNum) {
        if(pageNum==null){
            pageNum=1;
        }
        PageHelper.startPage(pageNum,3);
        List<BackOrderVo> list = iBackManageDao.queryBackAllOrders();
        if(list==null){
            throw new BusinessException("操作失败！");
        }else{
            PageInfo<BackOrderVo> pageInfo = new PageInfo<>(list);
            return pageInfo;
        }
    }

    @Override
    public int deliverGoods(String id) {
        int num = iBackManageDao.deliverGoods(id);
        if(num>0){
            return num;
        }else{
            throw new BusinessException("操作失败！");
        }
    }

    @Override
    public PageInfo<CommentVo> queryBackAllComments(Integer pageNum) {
        if(pageNum==null){
            pageNum=1;
        }
        PageHelper.startPage(pageNum,4);
        List<CommentVo> list = iBackManageDao.queryBackAllComments();
        if(list==null){
            throw new BusinessException("操作失败！");
        }else{
            PageInfo<CommentVo> pageInfo = new PageInfo<>(list);
            return  pageInfo;
        }
    }
//删除评论
    @Override
    public int commentIsDeleted(String id) {
        int num =iBackManageDao.commentIsDeleted(id);
        if(num>0){
            return  num;
        }else{
            throw new BusinessException("操作失败！");
        }
    }


}



