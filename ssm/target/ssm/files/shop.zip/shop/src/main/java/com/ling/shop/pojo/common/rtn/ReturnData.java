package com.ling.shop.pojo.common.rtn;

import java.io.Serializable;



/**
 * 返回对象
 */
public class ReturnData<T> implements Serializable {
	private static final long serialVersionUID = 1L;
	/** 是否成功 */
	private boolean success = false;
	/** 提示信息 */
	private String msg;
	private String code;
	private T data;
	
	public static <T> ReturnData<T> getSuccess() {
		ReturnData<T> r = new ReturnData<T>();
		r.setMsg("操作成功");
		r.setSuccess(true);
		return r;
	}
	
	public static <T> ReturnData<T> getSuccess(String msg) {
		ReturnData<T> r = new ReturnData<T>();
		r.setMsg(msg);
		r.setSuccess(true);
		return r;
	}
	
	public static <T> ReturnData<T> getSuccess(T data) {
		ReturnData<T> r = new ReturnData<T>();
		r.setSuccess(true);
		r.setData(data);
		return r;
	}
	
	public static <T> ReturnData<T> getError(String msg) {

		return getError(null, msg);
	}
	
	public static <T> ReturnData<T> getError(String code, String msg) {
		ReturnData<T> r = new ReturnData<T>();
		r.setSuccess(false);
		r.setCode(code);
		r.setMsg(msg);
		return r;
	}
	


	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public T getData() {
		return data;
	}

	public void setData(T data) {
		this.data = data;
	}

	public boolean isSuccess() {
		return success;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

}
