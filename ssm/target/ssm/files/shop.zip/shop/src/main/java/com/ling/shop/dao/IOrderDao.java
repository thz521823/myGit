package com.ling.shop.dao;

import com.ling.shop.pojo.po.Order;
import com.ling.shop.pojo.vo.OrderProMsgVo;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface IOrderDao {
//    查询订单页上商品信息
    OrderProMsgVo orderProMsg (@Param("productId")String productId);
    //生成订单
    int addOrder(Order order);
    //更改库存
    int updateStock (@Param("num")Integer num,@Param("productId") String productId);
}
