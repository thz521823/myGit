$(function () {
    $.ajax({
        url:"/getCategory",
        dataType:"json",
        success:function (data) {
            var context = "";
            data.data.forEach(item=>{
                context+=  '<a href="/category?categoryId='+item.id+ '">'+item.cgtypeName+'</a>'
            });
            $("#all_pros").after(context);
        }
    })
})