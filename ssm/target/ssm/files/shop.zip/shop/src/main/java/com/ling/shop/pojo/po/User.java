package com.ling.shop.pojo.po;

import lombok.Data;

import java.util.Date;
@Data
public class User {
    private String id;
    private String userName;
    private String password;
    private Date createTime;
    private Date loginTime;
    private String phoneNum;
    private Date  updateTime;
    private Integer isDeleted;
}
