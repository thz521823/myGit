package com.ling.shop.pojo.common;

public class TokenKey {
    private static final String TOKEN_KEY ="koken123";
    public static String getKey(){
        return  TOKEN_KEY;
    }
}
