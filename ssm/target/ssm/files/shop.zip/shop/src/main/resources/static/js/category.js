$(function () {
//价格升
$("#priSort0").click(function () {
    var url = window.location.href;
        if(url.indexOf("?")===-1){
            window.location.href =url+"?priSort=0"
        }else if(url.indexOf("?priSort")>0){
            window.location.href ="/category?priSort=0"
        }else if(url.indexOf("&priSort")>0){
            var index = url.indexOf("&priSort");
            var start = url.substring(0,index);
            var end = url.substring(index+"&priSort=1".length)
            window.location.href=start+end+"&priSort=0"
        }else{
            window.location.href=url+"&priSort=0"
        }
    });
//价格讲
    $("#priSort1").click(function () {
        var url = window.location.href;
        if(url.indexOf("?")===-1){
            window.location.href =url+"?priSort=1"
        }else if(url.indexOf("?priSort")>0){
            window.location.href ="/category?priSort=1"
        }else if(url.indexOf("&priSort")>0){
            var index = url.indexOf("&priSort");
            var start = url.substring(0,index);
            var end = url.substring(index+"&priSort=0".length)
            window.location.href=start+end+"&priSort=1"
        }else{
            window.location.href=url+"&priSort=1"
        }
    });
//查询
$("#search_but").click(function () {
    window.location.href="/category?search="+$("#search_inp").val();
})


});

