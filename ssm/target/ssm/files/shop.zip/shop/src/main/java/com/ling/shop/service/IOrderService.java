package com.ling.shop.service;

import com.ling.shop.pojo.po.Order;
import com.ling.shop.pojo.vo.OrderProMsgVo;

public interface IOrderService {
    //查询订单页上商品信息
    OrderProMsgVo orderProMsg (String productId);
    //生成订单
    int addOrderAndUpdateStock(Order order,String productId);
}
