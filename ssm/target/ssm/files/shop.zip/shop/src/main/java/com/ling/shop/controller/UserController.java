package com.ling.shop.controller;

import com.ling.shop.pojo.common.BusinessException;
import com.ling.shop.pojo.common.rtn.ReturnData;
import com.ling.shop.pojo.dto.UserDto;
import com.ling.shop.pojo.vo.UserVo;
import com.ling.shop.service.IUserService;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;


@Controller
public class UserController {
    @Autowired
    IUserService iUserService;


    //注册
    @RequestMapping("/register")
    public String getRegister() {
        return "register";
    }

    @ResponseBody
    @RequestMapping("/doRegister")
    public ReturnData<?> getDoRegister(UserDto userDto) {
        iUserService.insertUser(userDto);
        return ReturnData.getSuccess();
    }

    //判断是否存在
    @ResponseBody
    @RequestMapping("/isExist")
    public ReturnData<?> isExist(UserDto userDto) {
        UserVo userVo = iUserService.findUserByName(userDto.getUserName());
        if (userVo == null) {
            return ReturnData.getSuccess();
        }else {
            throw new BusinessException("用户名已存在！");
        }

    }

    //登陆页
    @RequestMapping("/login")
    public String getLogin() {
        return "login";
    }

    //判断登陆
    @ResponseBody
    @RequestMapping("/doLogin")
    public ReturnData<?> getDoLogin(UserDto userDto, HttpServletRequest request) {
        HttpSession session = request.getSession();
        userDto.setSessionId(session.getId());
        UserVo userVo = iUserService.login(userDto);
        session.setAttribute("user", userVo);

        return ReturnData.getSuccess(userVo);
    }

    //用户登出
    @RequestMapping("/logout")
    public String getLogout(HttpSession session) {
        session.removeAttribute("user");
        return "redirect:/";
    }


}
