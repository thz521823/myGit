package com.ling.shop.dao;


import com.ling.shop.controller.ProductsController;
import com.ling.shop.pojo.dto.ParamCategoryDto;
import com.ling.shop.pojo.po.Cgtype;
import com.ling.shop.pojo.po.Products;
import com.ling.shop.pojo.vo.ProductVo;
import com.ling.shop.pojo.vo.ProductsComVo;
import com.ling.shop.pojo.vo.ProductsDataVo;
import com.ling.shop.pojo.vo.ProductsDetailsVo;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public interface IProductsDao {
    List<ProductsDataVo> queryData(ParamCategoryDto paramCategoryDto);

    List<ProductsDataVo> searchData(ParamCategoryDto paramCategoryDto);

    ProductsDetailsVo queryByProductsId(@Param("productsId") String productsId);

    ProductVo getStock(@Param("productIndex")String productIndex, @Param("productsId")String productsId);

    List<Cgtype> getCategory();
    //根据productsId查询评论
    List<ProductsComVo> commentByProsId(String productsId);

}
