package com.ling.shop.config;
import com.ling.shop.pojo.common.BusinessException;
import com.ling.shop.pojo.common.rtn.ReturnData;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.lang.StringUtils;

import org.springframework.dao.DuplicateKeyException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.NoHandlerFoundException;



/**
 * 全局处理异常捕获
 */
@RestControllerAdvice
@Log4j2
public class GlobalExceptionHandler {
	private static final String COMMON_PROMPT = "系统异常，请联系管理员！";
	
	@ExceptionHandler(NoHandlerFoundException.class)
	public ReturnData<?> handlerNoFoundException(Exception e) {
		log.error(e.getMessage(), e);
		
		return ReturnData.getError("404", "路径不存在，请检查路径是否正确");
	}
	
	@ExceptionHandler(DuplicateKeyException.class)
	public ReturnData<?> handleDuplicateKeyException(DuplicateKeyException e){
		log.error(e.getMessage(), e);
		
		return ReturnData.getError("数据库中已存在该记录");
	}

	@ExceptionHandler(value = BusinessException.class)
	public ReturnData<?> businessExceptionHandle(BusinessException e) throws Exception {
		log.error(e.getMessage(), e);
		
		String code = e.getCode();
		String msg = StringUtils.defaultIfBlank(e.getMessage(), COMMON_PROMPT);
		
		ReturnData<Object> r = new ReturnData<>();
		r.setSuccess(false);
		r.setMsg(msg);
		r.setCode(code);
		r.setData(e.getData());
		
		return r;
	}

	@ExceptionHandler(value = Exception.class)
	public ReturnData<?> exceptionHandle(Exception e) throws Exception {
		log.error(e.getMessage(), e);
		
		String msg = StringUtils.defaultIfBlank(e.getMessage(), COMMON_PROMPT);
		
		return ReturnData.getError(msg);
	}
	
}
