package com.ling.shop.pojo.vo;

import lombok.Data;

import java.util.Date;
@Data
public class BackOrderVo {
    private Integer id;
    private String orderNum;
    private String totalPrice;
    private Integer num;
    private Date createTime;
    private Integer state;
    private String title;
    private Integer productsId;
    private String price;
    private String ownSpec;
    private String address;
    private  String recName;
    private String phoneNum;
    private Date updateTime;
    private String userName;
}
