package com.ling.shop.pojo.dto;

import lombok.Data;

@Data
public class AddReceiverDto {
    private String userId;
    private String address;
    private String recName;
    private String phoneNum;
}
