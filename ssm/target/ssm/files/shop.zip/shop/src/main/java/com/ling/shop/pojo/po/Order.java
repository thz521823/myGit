package com.ling.shop.pojo.po;

import lombok.Data;

import java.util.Date;
@Data
public class Order {
    private Integer id;
    private String orderNum;
    private Integer productId;
    private Double totalPrice;
    private Integer num;
   private Integer receiveId;
   private Date createTime;
   private Date updateTime;
   private Integer isDeleted;

}
