package com.ling.shop.controller;

import com.ling.shop.pojo.common.rtn.ReturnData;
import com.ling.shop.pojo.dto.AddReceiverDto;
import com.ling.shop.pojo.po.Receiver;
import com.ling.shop.service.IOrderService;
import com.ling.shop.service.IPersonalMsgService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.Map;


@Controller
public class PersonalMsgController {
    @Autowired
    IPersonalMsgService iPersonalMsgService;

    //收货页面
    @RequestMapping("/perMsgRec")
    public String getPersonalMsg() {
        return "perMsgRec";
    }

    //查询所有收货
    @ResponseBody
    @RequestMapping("/queryAllReceivers")
    public ReturnData<?> getQueryAllReceiver(String userId) {
        return ReturnData.getSuccess(iPersonalMsgService.queryAllReceivers(userId));
    }

    //增加收货
    @ResponseBody
    @RequestMapping("/addReceiver")
    public ReturnData<?> getAddReceiver(AddReceiverDto addReceiverDto) {
        iPersonalMsgService.addReceiver(addReceiverDto);
        return ReturnData.getSuccess();
    }

    //删除收货
    @ResponseBody
    @RequestMapping("/recIsDeleted")
    public ReturnData<?> getRecIsDeleted(String id) {
        iPersonalMsgService.isDeleted(id);
        return ReturnData.getSuccess();
    }

    //修改收货
    @ResponseBody
    @RequestMapping("/updateRec")
    public ReturnData<?> getUpdateRec(Receiver receiver) {
        iPersonalMsgService.updateRec(receiver);
        return ReturnData.getSuccess();
    }

    //个人中心订单页面
    @RequestMapping("/perMsgOrder")
    public String getPerMsgOrder(Map<String, Object> map, String userId, Integer pageNum) {
        map.put("pageInfo", iPersonalMsgService.queryAllOrders(userId, pageNum));
        return "perMsgOrder";
    }

    //确认收货
    @ResponseBody
    @RequestMapping("/sureGoods")
    public ReturnData<?> getSureGoods(String id) {
        iPersonalMsgService.sureGoods(id);
        return ReturnData.getSuccess();
    }

    //去评论
    @RequestMapping("/perMsgComment")
    public String getPerMsgComment(Map<String, Object> map, String productsId, String userId, Integer pageNum) {
        if (productsId !=null) {
            map.put("productsMsg",iPersonalMsgService.perMsgProducts(productsId));
        }

        map.put("pageInfo", iPersonalMsgService.queryCommentsByUserId(userId, pageNum));
        return "perMsgComment";
    }
    //增加评论
    @ResponseBody
    @RequestMapping("/addComment")
    public ReturnData<?> getAddComment(String userId,String productsId,String comContent){
        iPersonalMsgService.addComment(userId,productsId,comContent);
        return  ReturnData.getSuccess();
    }


}

