$(function () {
    $("#pros_manage").click(function () {
        $(".pros_tab").toggle();
    })
})