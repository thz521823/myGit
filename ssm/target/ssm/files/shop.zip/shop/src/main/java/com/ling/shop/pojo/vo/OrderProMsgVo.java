package com.ling.shop.pojo.vo;

import lombok.Data;

@Data
public class OrderProMsgVo {
    private Integer productsId;
    private String title;
    private String ownSpec;
    private Double price;
    private Integer productId;
}
