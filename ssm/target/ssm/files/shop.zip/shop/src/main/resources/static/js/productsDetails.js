
var productId;

var isSizeClick = false;
var isColorClick = false;

$(function () {

    //数量  减
    $("#count_del").click(function () {
        const count =parseInt($("#stock_inp").val())-1>0?parseInt($("#stock_inp").val())-1:1;
        $("#stock_inp").val(count);
    });
    //数量  加
    $("#count_add").click(function () {
        const str = $("#det_stock").html();
        const newStr = str.substring(2,str.length-1);
        const  count = parseInt($("#stock_inp").val())+1<parseInt(newStr)?parseInt($("#stock_inp").val())+1:parseInt(newStr);
        $("#stock_inp").val(count);

    });
    //点击商品详情
    $("#atr_span").click(function () {
        $(this).css({"outline":"1px red solid"});
        $("#com_span").css("outline","none");
        $("#pros_msg").css("display","block");
        $("#com_msg").css("display","none");
        }
    )
    //点击评价
    $("#com_span").click(function () {
            $(this).css({"outline":"1px red solid"});
            $("#atr_span").css("outline","none");
            $("#com_msg").css("display","block");
            $("#pros_msg").css("display","none");
        }
    )
    $("#pay_div").click(function () {
        if(isSizeClick===true&&isColorClick==true){
            $("#pay_error").html("");
            window.location.href="/order?productId="+productId+"&userId="+$("#session").html()+"&number="+$("#stock_inp").val();
        }else{
            $("#pay_error").html("请选择喜欢的尺码和颜色!")
        }
    })
});

var aj = function (str,productsId) {
    $.ajax({
        url:"/getStock",
        dataType:"json",
        data:{
            productIndex:str,
            productsId:productsId
        },
        method:"post",
        success:function (data) {
            console.log(data);
            $("#det_stock").html("库存"+data.data.stock+"件");
            $("#det_price").html("￥"+data.data.price);
            productId =data.data.productId;
        }
    });
};