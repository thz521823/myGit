package com.ling.shop.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.ling.shop.dao.IPersonalMsgDao;
import com.ling.shop.pojo.common.BusinessException;
import com.ling.shop.pojo.dto.AddReceiverDto;
import com.ling.shop.pojo.po.Products;
import com.ling.shop.pojo.po.Receiver;
import com.ling.shop.pojo.vo.CommentVo;
import com.ling.shop.pojo.vo.PerMsgOrderVo;
import com.ling.shop.service.IPersonalMsgService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.BatchUpdateException;
import java.util.List;

@Service
public class PersonalMsgServiceImpl implements IPersonalMsgService {
    @Autowired
    IPersonalMsgDao iPersonalMsgDao;
//查询所有收货信息
    @Override
    public List<Receiver> queryAllReceivers(String userId) {
        List<Receiver> list = iPersonalMsgDao.queryAllReceivers(userId);
        if(list==null){
            throw new BusinessException("操作失败！");
        }else{
            return  list;
        }

    }
//增加收货
    @Override
    public int addReceiver(AddReceiverDto addReceiverDto) {
        int num = iPersonalMsgDao.addReceiver(addReceiverDto);
        if(num>0){
            return num;
        }else{
            throw new BusinessException("操作失败！");
        }
    }
    //删除收货
    @Override
    public int isDeleted(String id) {
        int num = iPersonalMsgDao.recIsDeleted(id);
        if(num >0){
            return num;
        }else{
            throw new BusinessException("操作失败！");
        }
    }
//更新收货
    @Override
    public int updateRec(Receiver receiver) {
        int num = iPersonalMsgDao.updateRec(receiver);
        if(num >0){
            return num;
        }else{
            throw new BusinessException("操作失败！");
        }
    }
    //根据userId查询所有订单
    @Override
    public PageInfo<PerMsgOrderVo> queryAllOrders(String userId,Integer pageNum) {
            if(pageNum==null){
                pageNum =1;
            }
        PageHelper.startPage(pageNum,2);
            List<PerMsgOrderVo> list = iPersonalMsgDao.queryAllOrders(userId);
            if(list ==null){
                throw new BusinessException("操作失败！");
            }else{
                PageInfo<PerMsgOrderVo> pageInfo = new PageInfo<>(list);
                return  pageInfo;
            }
    }

    @Override
    public int sureGoods(String id) {
        int num = iPersonalMsgDao.sureGoods(id);
        if(num>0){
            return num;
        }else{
            throw new BusinessException("操作失败！");
        }
    }
    //根据userId查询所有评论
    @Override
    public PageInfo<CommentVo> queryCommentsByUserId(String userId, Integer pageNum) {


        if(pageNum==null){
            pageNum = 1;
        }
        PageHelper.startPage(pageNum,2);
        List<CommentVo> list = iPersonalMsgDao.queryCommentsByUserId(userId);
        PageInfo<CommentVo> pageInfo = new PageInfo<>(list);
        return pageInfo;
    }

    @Override
    public Products perMsgProducts(String productsId) {
        Products products = iPersonalMsgDao.perMsgProducts(productsId);
        if(products==null){
            throw new BusinessException("操作失败！");
        }else{
            return products;
        }
    }

    @Override
    public int addComment(String userId, String productsId, String comContent) {
        int num = iPersonalMsgDao.addComment(userId,productsId,comContent);
        if(num>0){
            return  num;
        }else{
            throw new BusinessException("操作失败！");
        }
    }


}
