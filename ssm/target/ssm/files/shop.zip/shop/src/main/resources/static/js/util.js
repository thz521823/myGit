//地址栏中添加参数
function addParam(param,pageNum,num,pageUrl){
    var url = window.location.href;
    if(url.indexOf("?")===-1){
        url =url+"?"+param+"="+num
    }else if(url.indexOf("?"+param)>0){
        url = "/"+pageUrl+"?"+param+"="+num
    }else if(url.indexOf("&"+param)>0){
        var index = url.indexOf("&"+param);
        var start = url.substring(0,index);
        var end = url.substring(index+("&"+param+"="+pageNum).length)
        url=start+end+"&"+param+"="+num
    }else{
        url=url+"&"+param+"="+num
    }
    return url;
}

//上一页
function prePage(param,pageNum,pageUrl){
    var num;
    if (pageNum<=1) {
        num = 1
    } else {
        num = pageNum-1;
    }
    return addParam(param, pageNum, num, pageUrl);
}

//下一页
function nextPage(param,pageNum,maxPage,pageUrl) {
    var num;
    if (pageNum>=maxPage) {
        num = maxPage;
    } else {
        num = pageNum+1;
    }
   return addParam(param, pageNum, num, pageUrl);
}
//搜索页
function surePage(param,pageNum,inNum,maxPage,pageUrl) {
    var num;
    if(inNum<1){
        num =1
    }else if(inNum>maxPage){
        num = maxPage
    }else{
        num = inNum;
    }
    return addParam(param,pageNum,num,pageUrl);
}