package com.ling.shop.pojo.po;

import lombok.Data;

import java.util.Date;

@Data
public class Product {
    private Integer id;
    private Integer productsId;
    private Double price;
    private Integer stock;
    private String productIndex;
    private String ownSpec;
    private Date createTime;
    private Date updateTime;
    private Integer isDeleted;
}
