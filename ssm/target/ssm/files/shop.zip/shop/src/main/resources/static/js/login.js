$(function () {
    //用户名
   var isError = false;
    $("#userName").blur(function () {
        if($(this).val()===""){
            isError=false;
            $("#log_tip").html("请输入用户名!")
        }else{
            isError = true;
            $("#log_tip").html("");
        }
    });
    //登陆
    $("#log_but").click(function () {
        if(isError===true){
            $.ajax({
                url:"/doLogin",
                dataType:"json",
                method:"post",
                data:{
                    userName:$("#userName").val(),
                    password:$("#password").val()
                },
                success:function (data) {
                    if(!data.success){
                        $("#log_tip").html("用户名或密码错误！")
                    }else if(data.data.power===0){

                        window.location.href="/"
                    }else{

                        window.location.href="/backManageUser"
                    }
                }
            })
        }
    })
})