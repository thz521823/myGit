package com.ling.shop.pojo.po;



import lombok.Data;

import java.util.Date;
@Data
public class Comment {
    private Integer id;
    private String comContent;
    private Integer userId;
    private Integer productsId;
    private Date createTime;
    private Date updateTime;
    private Integer isDeleted;
}
