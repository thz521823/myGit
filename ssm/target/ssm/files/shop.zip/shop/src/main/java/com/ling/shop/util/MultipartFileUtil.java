package com.ling.shop.util;

import com.ling.shop.pojo.common.BusinessException;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;

public class MultipartFileUtil {

    public static void saveFile(MultipartFile file,String fileName) throws IOException {
        if (!file.isEmpty()) {
            //参数即可获得项目相对路径
            String filePath = System.getProperty("user.dir") + File.separator + "src" + File.separator + "main" +
                    File.separator + "resources" + File.separator + "static" + File.separator + "img" + File.separator +
                    File.separator + "productImg" + File.separator;
            File dest = new File(filePath + fileName);
            if (!dest.getParentFile().exists()) {
                dest.getParentFile().mkdirs();
            }
            file.transferTo(dest);
        }else{
        throw new BusinessException("上传的是个空文件！");
        }
    }
}
