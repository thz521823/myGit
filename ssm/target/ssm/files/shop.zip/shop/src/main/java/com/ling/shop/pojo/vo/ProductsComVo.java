package com.ling.shop.pojo.vo;

import lombok.Data;

import java.util.Date;
@Data
public class ProductsComVo {
    private String comContent;
    private Date createTime;
    private String userName;
}
