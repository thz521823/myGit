package com.ling.shop.pojo.po;

import lombok.Data;

import java.util.Date;

@Data
public class Cgtype {
    private Integer id;
    private String cgtypeName;
    private Date createTime;
    private Date updateTime;
    private Integer isDeleted;
}
