package com.ling.shop.service;

import com.ling.shop.pojo.dto.UserDto;
import com.ling.shop.pojo.vo.UserVo;

public interface IUserService {

    UserVo findUserByName(String name);

    boolean insertUser(UserDto userDto);

    UserVo login(UserDto userDto);

}
