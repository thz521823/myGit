package com.ling.shop.service.impl;

import com.ling.shop.dao.IUserDao;
import com.ling.shop.pojo.common.BusinessException;
import com.ling.shop.pojo.dto.UserDto;
import com.ling.shop.pojo.vo.UserVo;
import com.ling.shop.service.IUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class UserServiceImpl implements IUserService {
    @Autowired
    private IUserDao iUserDao;


    @Override
    public UserVo findUserByName(String name) {

            return iUserDao.findUserByName(name);


    }

    @Override
    public boolean insertUser(UserDto userDto) {
        UserVo userVo = iUserDao.findUserByName(userDto.getUserName());
        if (userVo == null) {
            iUserDao.insertUser(userDto);
            return true;
        } else {
            throw new BusinessException("操作失败");
        }
    }

    public UserVo login(UserDto userDto) {
        UserVo userVo = iUserDao.findUserByName(userDto.getUserName());
        if (userVo != null && userVo.getPassword().equals(userDto.getPassword())) {
                int num = iUserDao.updateLoginTimeSessionId(userDto.getUserName(),userDto.getSessionId());
                if(num>0){
                    return userVo;
                }else{
                    throw new BusinessException("操作失败!");
                }

        } else {
            throw new BusinessException("用户名或密码错误");
        }
    }


}
