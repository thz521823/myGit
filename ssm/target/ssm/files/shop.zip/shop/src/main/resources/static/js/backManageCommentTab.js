$(function () {
    $(".bm_com_del").on("click",function () {
        var id = $(this).parent().parent().children(":first").html();
        $.ajax({
            url:"/commentIsDeleted",
            dateType:"json",
            data:{
                id:id
            },
            method:"post",
            success:function (data) {
                if(data.success){
                    window.location.reload();
                }
            }
        });
    })
})