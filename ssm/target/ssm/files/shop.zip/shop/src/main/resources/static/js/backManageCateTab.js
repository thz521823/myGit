$(function () {
//添加分类
    $("#bm_addCate_but").click(function () {
        $("#bm_addCate_div").css("visibility", "visible");
    });

//删除分类
    $(".bm_cate_del").on("click", function () {
        var id = $(this).parent().parent().children(":first").html();

        $.ajax({
            url: "/isDeletedCate",
            method: "post",
            dateType: "json",
            data: {
                id: id
            },
            success: function (data) {
                if (data.success) {
                    window.location.reload();
                }
            }
        });
    })
});

//阻止submit
function aaa(){
    if($("#categoryName").val()===""){

        return false;
    }else{
        return true;
    }
}