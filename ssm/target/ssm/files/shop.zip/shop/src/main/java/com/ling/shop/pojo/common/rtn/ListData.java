package com.ling.shop.pojo.common.rtn;

import java.util.List;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * 返回列表的数据
 */
@Getter
@Setter
@ToString
public class ListData<T> implements java.io.Serializable {
	private static final long serialVersionUID = 1L;
	
	/** 列表数据 */
	private List<T> list;
	/** 总记录数 */
	private Long total;
	
	private int pageSize;
	
	private int pageNum;

}
