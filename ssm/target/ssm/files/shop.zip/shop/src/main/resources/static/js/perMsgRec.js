//判断有效手机号
$(function () {
    var userId = $("#session").html();
    if (userId !== "") {
        var context = "";
        $.ajax({
            url: "queryAllReceivers",
            data: {
                userId: userId
            },
            dataType: "json",
            method: "post",
            success: function (data) {
                if (data.success) {
                    data.data.forEach(item => {
                        context += '<div class="receiverList">' +
                            '<span style="display: none">' + item.id + '</span>' +
                            '<span style="margin-left: 20px">' + item.address + '</span>' +
                            '<span>' + item.recName + '</span>' +
                            '<span>' + item.phoneNum + '</span>' +
                            '<div class="re_del">删除</div>' +
                            '<div class="re_upd" style="margin:0 20px;">编辑</div>' +
                            '</div>'
                    })
                    $("#re_div_hr1").after(context);
                }
            }
        });
        //增加收货
        $("#re_add_but").click(function () {
            if ($("#add_address").val() !== "" && $("#add_recName").val() !== "" && $("#add_phoneNum").val() !== "" && isTrue($("#add_phoneNum").val()))
                $.ajax({
                    url: "/addReceiver",
                    dataType: "json",
                    method: "post",
                    data: {
                        userId: userId,
                        address: $("#add_address").val(),
                        recName: $("#add_recName").val(),
                        phoneNum: $("#add_phoneNum").val()
                    },
                    success: function (data) {
                        if (data.success) {
                            window.location.reload();
                        }
                    }
                });
        });

        //删除收货
        $("#re_div").on("click", ".re_del", function () {
            var id = $(this).parent().children(":first").html();

                $.ajax({
                    url: "/recIsDeleted",
                    dataType: "json",
                    method: "post",
                    data: {
                        id: id,
                    },
                    success: function (data) {
                        if (data.success) {
                            window.location.reload();
                        }
                    }
                });
        })

        //修改收货
        $("#re_div").on("click",".re_upd",function () {

            $("#re_upd_div").css("display","block");
            var arr1 =$(this).parent().children();
           var arr2 =$("#re_upd_div input");
           for(var i =0;i<arr2.length;i++){
               arr2[i].value=arr1[i].innerHTML;
           }
        });
        $("#re_upd_but").click(function () {
            if ($("#upd_address").val() !== "" && $("#upd_recName").val() !== "" && $("#upd_phoneNum").val() !== "" && isTrue($("#upd_phoneNum").val())){
                $.ajax({
                    url:"/updateRec",
                    dataType:"json",
                    method:"post",
                    data:{
                        id: $("#upd_id").val(),
                        address: $("#upd_address").val(),
                        recName: $("#upd_recName").val(),
                        phoneNum: $("#upd_phoneNum").val()
                    },
                    success:function (data) {
                        if(data.success){
                            window.location.reload();
                        }
                    }
                });
            }
        });

    }
});

//判断11位手机号码
function isTrue(str) {
    var rep = /[0-9]/;
    var length = str.length;
    if (rep.test(str) === true && length === 11) {
        return true;
    } else {
        return false;
    }
}