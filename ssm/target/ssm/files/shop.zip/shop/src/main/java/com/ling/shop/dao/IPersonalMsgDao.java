package com.ling.shop.dao;

import com.github.pagehelper.PageInfo;
import com.ling.shop.pojo.dto.AddReceiverDto;
import com.ling.shop.pojo.po.Products;
import com.ling.shop.pojo.po.Receiver;
import com.ling.shop.pojo.vo.CommentVo;
import com.ling.shop.pojo.vo.PerMsgOrderVo;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IPersonalMsgDao {
    //查询所有收货信息
    List<Receiver> queryAllReceivers(@Param("userId")String userId);

    //增加收货信息
    int addReceiver(AddReceiverDto addReceiverDto);

    //删除收货
    int recIsDeleted(@Param("id") String id);
    //修改收货
    int updateRec(Receiver receiver);

    //根据userId查询所有订单
    List<PerMsgOrderVo> queryAllOrders(@Param("userId")String userId);
    //确认收货
    int sureGoods (String id);
    //根据userId查询评论
    List<CommentVo> queryCommentsByUserId(@Param("userId")String userId);
   // 根据productsId 查询商品
    Products perMsgProducts(@Param("productsId") String productsId);
    //增加评论
    int addComment(String userId,String productsId,String comContent);
}
