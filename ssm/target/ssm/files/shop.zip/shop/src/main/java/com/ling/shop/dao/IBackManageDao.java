package com.ling.shop.dao;

import com.ling.shop.pojo.po.Picture;
import com.ling.shop.pojo.po.Product;
import com.ling.shop.pojo.po.Products;
import com.ling.shop.pojo.po.User;
import com.ling.shop.pojo.vo.BackOrderVo;
import com.ling.shop.pojo.vo.CommentVo;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IBackManageDao {
    //查询所有用户
    List<User> findAllUsers();
//恢复。注销
    boolean updateUserIsDeleted(@Param("isDeleted")String isDeleted,@Param("id") String id);
//查询所有商品
    List<Products> getAllpros();
//增加分类
    int addCategory(@Param("categoryName")String categoryName);
//删除分类
    int isDeletedCate(@Param("id") String id);
//查询所有图片
    List<Picture> getAllpics();
    //增加商品
    int  addPros(Products products);
    //删除商品
    int prosIsDeleted(@Param("id")String id);
    //修改商品
    int updatePros(Products products);
    //获取相关库存
    List<Product> getProduct(@Param("productsId")String productsId);
    //增加product
    int addProduct (Product product);
    //删除product
    int proIsDeleted(String id);
    //修改product
    int updatePro(Product product);
    //增加图片
    int addPic(Picture picture);
    //删除图片
    int picIsDeleted(@Param("id") String id);
    //查询所有订单
    List<BackOrderVo> queryBackAllOrders();
    //发货
    int deliverGoods (String id);
    //查询所有评论
    List<CommentVo> queryBackAllComments();
    //删除评论
    int commentIsDeleted(String id);
}
