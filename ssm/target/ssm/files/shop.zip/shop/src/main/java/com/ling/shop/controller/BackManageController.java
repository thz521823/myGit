package com.ling.shop.controller;

import com.ling.shop.pojo.common.rtn.ReturnData;
import com.ling.shop.pojo.po.Picture;
import com.ling.shop.pojo.po.Product;
import com.ling.shop.pojo.po.Products;
import com.ling.shop.service.IBackManageService;
import com.ling.shop.service.IPersonalMsgService;
import com.ling.shop.service.IProductsService;
import com.ling.shop.util.MultipartFileUtil;
import com.ling.shop.util.UUIDGenerator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.IOException;
import java.util.Map;

@Controller
public class BackManageController {
    @Autowired
    IBackManageService iBackManageService;
    @Autowired
    IProductsService iProductsService;

    @RequestMapping("/backManage")
    public String getBackManage() {
        return "redirect:backManageUser";
    }

    //查询所有用户
    @RequestMapping("/backManageUser")
    public String getAllUsers(Map<String, Object> map, String pageNum) {
        map.put("pageInfo", iBackManageService.findAllUsers(pageNum));
        return "backManageUser";
    }

    //恢复用户，注销用户；
    @ResponseBody
    @RequestMapping("/updateUserIsDeleted")
    public ReturnData<?> getUpdate(String isDeleted, String id) {
        iBackManageService.updateIsDeleted(isDeleted, id);
        return ReturnData.getSuccess();
    }

    //商品表
    @RequestMapping("/backManageProsTab")
    public String getBackManageProsTab(Map<String, Object> map, String prosPageNum) {
        map.put("prosPageInfo", iBackManageService.getAllpros(prosPageNum));
        return "backManageProsTab";
    }

    //商品分类表
    @RequestMapping("/backManageCateTab")
    public String getBackManageCateTab(Map<String, Object> map, String catePageNum) {
        map.put("catePageInfo", iBackManageService.getAllCategory(catePageNum));
        return "backManageCateTab";
    }

    //增加分类
    @RequestMapping("/addCategory")
    public String getAddCategory(String categoryName) {
        iBackManageService.addCategory(categoryName);
        return "redirect:backManageCateTab";
    }

    //删除分类
    @ResponseBody
    @RequestMapping("/isDeletedCate")
    public ReturnData<?> getIsDeletedCate(String id) {
        iBackManageService.isDeletedCate(id);
        return ReturnData.getSuccess();
    }

    //查询所有图片
    @RequestMapping("/backManagePicTab")
    public String getBackManagePicTab(Map<String, Object> map, String picPageNum) {
        map.put("pictureList", iBackManageService.getAllpics(picPageNum));
        return "backManagePicTab";
    }

    //增加商品
    @ResponseBody
    @RequestMapping("/addPros")
    public ReturnData<?> getAddPros(Products products) {
        System.out.println(UUIDGenerator.generateJDK());
        products.setProductsNum(UUIDGenerator.generateJDK());
        iBackManageService.addPros(products);
        return ReturnData.getSuccess();

    }

    //删除商品
    @ResponseBody
    @RequestMapping("/prosIsDeleted")
    public ReturnData<?> getProsIsDeleted(String id) {
        iBackManageService.prosIsDeleted(id);
        return ReturnData.getSuccess();
    }

    //修改商品
    @ResponseBody
    @RequestMapping("/updatePros")
    public ReturnData<?> getUpdatePros(Products products) {
        int num = iBackManageService.updatePros(products);
        return ReturnData.getSuccess();
    }

    //获取相关库存
    @ResponseBody
    @RequestMapping("/getProduct")
    public ReturnData<?> getProduct(String productsId) {
        return ReturnData.getSuccess(iBackManageService.getProduct(productsId));
    }

    //增加product
    @ResponseBody
    @RequestMapping("/addProduct")
    public ReturnData<?> getAddProduct(Product product) {
        iBackManageService.addProduct(product);
        return ReturnData.getSuccess();
    }

    //删除Product
    @ResponseBody
    @RequestMapping("/proIsDeleted")
    public ReturnData<?> getProIsDeleted(String id) {
        iBackManageService.proIsDeleted(id);
        return ReturnData.getSuccess();
    }

    //修改Product
    @ResponseBody
    @RequestMapping("/updatePro")
    public ReturnData<?> getUpdatePro(Product product) {
        iBackManageService.updatePro(product);
        return ReturnData.getSuccess();
    }

    //增加，上传图片
    @ResponseBody
    @RequestMapping("/uploadPic")
    public ReturnData<?> getUploadPic(@RequestParam("uploadPic") MultipartFile[] files) throws IOException {
        String[] picUrls = new String[files.length];
        for (int i = 0; i < files.length; i++) {
            String[] strArr = files[i].getOriginalFilename().split("\\\\");
            String fileName = strArr[strArr.length - 1];
            MultipartFileUtil.saveFile(files[i], fileName);
            picUrls[i] = "img/productImg/" + fileName;
        }
        Picture picture = new Picture();
        picture.setDisPic(picUrls[0]);
        picture.setDetA(picUrls[1]);
        picture.setDetB(picUrls[2]);
        picture.setDetC(picUrls[3]);
        iBackManageService.addPic(picture);

        return ReturnData.getSuccess();
    }

    //删除图片
    @ResponseBody
    @RequestMapping("/picIsDeleted")
    public ReturnData<?> getPicIsDeleted(String id) {
        iBackManageService.pisIsDeleted(id);
        return ReturnData.getSuccess();
    }
    //订单管理页
    @RequestMapping("/backManageOrderTab")
    public String getBackAllOrders(Map<String,Object>map,Integer pageNum){
        map.put("pageInfo",iBackManageService.queryBackAllOrders(pageNum));
        return "backManageOrderTab";
    }
    //发货
    @ResponseBody
    @RequestMapping("/deliver")
    public ReturnData<?> getDeliver(String id){
        iBackManageService.deliverGoods(id);
        return ReturnData.getSuccess();
    }
    //查询所有评论
    @RequestMapping("/backManageCommentTab")
    public String getBackManageCommentTab(Map<String,Object>map,Integer pageNum){
        map.put("pageInfo",iBackManageService.queryBackAllComments(pageNum));
        return "backManageCommentTab";
    }
    //删除评论
    @ResponseBody
    @RequestMapping("/commentIsDeleted")
    public ReturnData<?> getCommentIsDeleted(String id){
        iBackManageService.commentIsDeleted(id);
        return ReturnData.getSuccess();
    }

}
