package com.ling.shop.pojo.vo;

import com.ling.shop.pojo.po.Products;
import lombok.Data;

@Data
public class ProductsDataVo{
    private Integer id;
    private String title;
    private Double displayPrice;
    private Integer state;
    private String disPic;
}
