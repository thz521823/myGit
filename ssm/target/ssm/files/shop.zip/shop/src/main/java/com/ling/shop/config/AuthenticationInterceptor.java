package com.ling.shop.config;
import com.ling.shop.pojo.vo.UserVo;
import com.ling.shop.service.IUserService;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


public class AuthenticationInterceptor implements HandlerInterceptor {
    @Autowired
    IUserService iUserService;

    @Override
    public boolean preHandle(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object object) throws Exception {
        HttpSession session = httpServletRequest.getSession();
      UserVo user = (UserVo)session.getAttribute("user");
      String sessionId = session.getId();

        if(user==null){
            httpServletResponse.sendRedirect("/login");
            return false;
        }
        if(!sessionId.equals(iUserService.findUserByName(user.getUserName()).getSessionId())){
            httpServletResponse.sendRedirect("/login");
            return false;
        }
        //权限
        Integer group = iUserService.findUserByName(user.getUserName()).getPower();
        String url = httpServletRequest.getServletPath();
        if(url.startsWith("/back")&&group==0){
            httpServletResponse.sendRedirect("/login");
            return false;
        }
        return  true;

    }

    @Override
    public void postHandle(HttpServletRequest httpServletRequest,
                           HttpServletResponse httpServletResponse,
                           Object o, ModelAndView modelAndView) throws Exception {

    }

    @Override
    public void afterCompletion(HttpServletRequest httpServletRequest,
                                HttpServletResponse httpServletResponse,
                                Object o, Exception e) throws Exception {
    }
}