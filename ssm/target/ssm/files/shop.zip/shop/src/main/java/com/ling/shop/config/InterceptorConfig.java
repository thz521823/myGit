package com.ling.shop.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class InterceptorConfig implements WebMvcConfigurer {


    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        InterceptorRegistration addInterceptor =  registry.addInterceptor(authenticationInterceptor());
        addInterceptor.addPathPatterns("/**");
        addInterceptor.excludePathPatterns("/static/**");
        addInterceptor.excludePathPatterns("/login");
        addInterceptor.excludePathPatterns("/register");
        addInterceptor.excludePathPatterns("/doRegister");
        addInterceptor.excludePathPatterns("/");
        addInterceptor.excludePathPatterns("/productsDetails");
        addInterceptor.excludePathPatterns("/category");
        addInterceptor.excludePathPatterns("/getCategory");
        addInterceptor.excludePathPatterns("/kaptcha");
        addInterceptor.excludePathPatterns("/isExist");
        addInterceptor.excludePathPatterns("/doLogin");
        addInterceptor.excludePathPatterns("/codeIsTrue");


    }
    @Bean
    public AuthenticationInterceptor authenticationInterceptor() {
        return new AuthenticationInterceptor();
    }
}