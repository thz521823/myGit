$(function () {

    var userId = $("#session").html();
    var productsId = $("#productsId").html();
    $("#per_com_but").on("click",function () {
        var content =$("#com_content").val();
        if(content&&userId&&productsId&&content!==""){
               $.ajax({
                   url:"/addComment",
                   method:"post",
                   dateType:"json",
                   data:{
                       userId:userId,
                       productsId:productsId,
                       comContent:content,
                   },
                   success:function(data){
                       if(data.success){
                           window.location.reload();
                       }
                   }
               });
            }
    });
})