package com.ling.shop.pojo.vo;

import lombok.Data;

@Data
public class UserVo {
    private Integer id;
    private String userName;
    private String password;
    private String sessionId;
    private Integer power;
}
