package com.ling.shop.pojo.po;

import lombok.Data;

import java.util.Date;

@Data
public class Products {
    private Integer id;
    private String title;
    private Double displayPrice;
    private Integer categoryId;
    private Integer pictureId;
    private String productsNum;
    private String brind;
    private String  attrList;
    private Integer state;
    private Date createTime;
    private Date updateTime;
    private Integer isDeleted;

}
