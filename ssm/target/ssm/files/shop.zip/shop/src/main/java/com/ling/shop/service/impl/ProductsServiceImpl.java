package com.ling.shop.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.ling.shop.dao.IProductsDao;
import com.ling.shop.pojo.common.BusinessException;
import com.ling.shop.pojo.dto.ParamCategoryDto;
import com.ling.shop.pojo.po.Cgtype;
import com.ling.shop.pojo.vo.ProductVo;
import com.ling.shop.pojo.vo.ProductsComVo;
import com.ling.shop.pojo.vo.ProductsDataVo;
import com.ling.shop.pojo.vo.ProductsDetailsVo;
import com.ling.shop.service.IProductsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
@Service
public class ProductsServiceImpl implements IProductsService {
    @Autowired
    IProductsDao iProductsDao;


    @Override
    public PageInfo<ProductsDataVo> getData(ParamCategoryDto paramCategoryDto) {

        if(paramCategoryDto.getPageNum()==null){
            paramCategoryDto.setPageNum(1);
        };
        if(paramCategoryDto.getPageSize()==null){
            paramCategoryDto.setPageSize(4);
        }
        //使用分页插件
        PageHelper.startPage(paramCategoryDto.getPageNum(),paramCategoryDto.getPageSize());
        List<ProductsDataVo> list = new ArrayList<>();
        if(paramCategoryDto.getSearch()==null||paramCategoryDto.getSearch().equals("")){
            list =iProductsDao.queryData(paramCategoryDto);
        }else {
            String search = paramCategoryDto.getSearch();
            paramCategoryDto.setSearch("%"+search+"%");
            list = iProductsDao.searchData(paramCategoryDto);
        }
        PageInfo<ProductsDataVo> pageInfo = new PageInfo<ProductsDataVo>(list);

     return pageInfo;
    }

    @Override
    public ProductsDetailsVo getDetails(String productsId) {

        return iProductsDao.queryByProductsId(productsId);
    }

    @Override
    public ProductVo getStock(String productIndex, String productsId) {
        if(iProductsDao.getStock(productIndex,productsId)==null){
            throw new BusinessException("操作失败");
        }else {
            return iProductsDao.getStock(productIndex,productsId);
        }
    }

    @Override
    public List<Cgtype> getCategory() {
        if(iProductsDao.getCategory()==null){
            throw new BusinessException("操作失败！");
        }else{
            return iProductsDao.getCategory();
        }
    }
//根据productsId查询评论
    @Override
    public PageInfo<ProductsComVo> commentByProsId(String productsId, Integer pageNum) {
        if(pageNum==null){
            pageNum =1;
        }
        PageHelper.startPage(pageNum,10);
        List<ProductsComVo> list = iProductsDao.commentByProsId(productsId);
        if(list==null){
            throw new BusinessException("操作失败！");
        }else{
            PageInfo<ProductsComVo> pageInfo = new PageInfo<>(list);
            return pageInfo;
        }
    }
}
