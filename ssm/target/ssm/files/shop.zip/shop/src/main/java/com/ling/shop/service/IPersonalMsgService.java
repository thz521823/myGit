package com.ling.shop.service;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageInfo;
import com.ling.shop.pojo.dto.AddReceiverDto;
import com.ling.shop.pojo.po.Products;
import com.ling.shop.pojo.po.Receiver;
import com.ling.shop.pojo.vo.CommentVo;
import com.ling.shop.pojo.vo.PerMsgOrderVo;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface IPersonalMsgService {
    //查询所有收获信息
    List<Receiver> queryAllReceivers (String userId);
    //增加收货信息
    int addReceiver (AddReceiverDto addReceiverDto);
    //删除商品
    int isDeleted(String id);
    //修改收货
    int updateRec(Receiver receiver);

    //根据userId查询所有订单
    PageInfo<PerMsgOrderVo> queryAllOrders(String userId,Integer pageNum);
    //确认收货
    int sureGoods(String id);
    //根据userId查询所有评论
    PageInfo<CommentVo> queryCommentsByUserId(String userId,Integer pageNum);
    // 根据productsId 查询商品
    Products perMsgProducts(String productsId);
    //增加评论
    int addComment(String userId,String productsId,String comContent);

}
