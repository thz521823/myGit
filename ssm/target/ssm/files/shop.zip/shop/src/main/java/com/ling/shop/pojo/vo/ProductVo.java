package com.ling.shop.pojo.vo;

import lombok.Data;

@Data
public class ProductVo {
    private String productId;
    private String stock;
    private String price;
}
