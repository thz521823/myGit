package com.ling.shop.pojo.dto;

import lombok.Data;


@Data
public class UserDto {
    private String userName;
    private String password;
    private String phoneNum;
    private String sessionId;
}
