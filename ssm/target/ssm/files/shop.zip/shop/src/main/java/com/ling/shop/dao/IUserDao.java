package com.ling.shop.dao;

import com.ling.shop.pojo.dto.UserDto;
import com.ling.shop.pojo.po.User;
import com.ling.shop.pojo.vo.UserVo;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IUserDao {

    UserVo findUserByName(@Param(value="userName") String userName);

    boolean insertUser(UserDto userDto);

    int updateLoginTimeSessionId(@Param(value="userName") String userName,@Param("sessionId")String sessionId);


}
