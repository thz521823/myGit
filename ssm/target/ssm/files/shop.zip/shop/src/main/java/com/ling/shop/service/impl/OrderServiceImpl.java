package com.ling.shop.service.impl;

import com.ling.shop.dao.IOrderDao;
import com.ling.shop.pojo.common.BusinessException;
import com.ling.shop.pojo.po.Order;
import com.ling.shop.pojo.vo.OrderProMsgVo;
import com.ling.shop.service.IOrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class OrderServiceImpl implements IOrderService {
    @Autowired
    IOrderDao iOrderDao;
    @Override
    //查询订单中的商品信息
    public OrderProMsgVo orderProMsg(String productId) {
        OrderProMsgVo orderProMsgVo  = iOrderDao.orderProMsg(productId);
        if(orderProMsgVo==null){
            throw new BusinessException("操作失败！");
        }else{
            return orderProMsgVo;
        }
    }
//生成订单
    @Override
    public int addOrderAndUpdateStock(Order order, String productId) {
        int numUp = iOrderDao.updateStock(order.getNum(),productId);
        if(numUp>0){
            int numAdd = iOrderDao.addOrder(order);
            if(numAdd>0){
                return numAdd;
            }else{
                throw new BusinessException("操作失败！");
            }
        }else{
            throw new BusinessException("库存不足！");
        }
    }


}
