package com.ling.shop.pojo.vo;

import com.ling.shop.pojo.po.Comment;
import lombok.Data;

@Data
public class CommentVo extends Comment {
    private String userName;
    private Integer productsId;
    private String title;
}
