package com.ling.shop.pojo.po;

import lombok.Data;

import java.util.Date;

@Data
public class Picture {
    private Integer id;
    private String disPic;
    private String detA;
    private String detB;
    private String detC;
    private Date createTime;
    private Date updateTime;
    private Integer isDeleted;
}
