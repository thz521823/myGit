//判断input增加，修改字段空时，不能提交
function isSub(arr){
  for(var i =0;i<arr.length;i++){
      if(arr[i].value===""){
          return false;
      }
  }
  return true;
}

$(function () {
    //增加商品
    $("#bm_addPros_but").click(function () {
        $("#bm_addPros_div").css("visibility","visible");
    });
    $("#bm_add_but").click(function () {
        if(isSub($("#bm_add_tr [type]"))){
            $.ajax({
                url:"addPros",
                dataType: "json",
                method:"post",
                data:{
                    title:$("#add_title").val(),
                    displayPrice:$("#add_displayPrice").val(),
                    brind:$("#add_brind").val(),
                    attrList:$("#add_attrList").val(),
                    state:$("#add_state").val(),
                    categoryId:$("#add_categoryId").val(),
                    pictureId:$("#add_pictureId").val()
                },
                success:function (data) {
                    if(data.success){
                        window.location.reload();
                    }
                }
            });
        }
    });


    //删除商品
    $(".bm_pros_del").on("click",function () {
        var id = $(this).parent().parent().children(":first").html();
        $.ajax({
            url:"/prosIsDeleted",
            method:"post",
            dataType:"json",
            data:{
                id:id
            },
            success:function (data) {
                    if(data.success){
                        window.location.reload();
                    }
            }
        });

    })
    //修改商品
    $(".bm_pros_upd").on("click",function () {
        $("#bm_updatePros_div").css("visibility","visible");
            var arr =$(this).parent().parent().children();
            var length=arr.length-5;
            for(var i = 0;i<length;i++){
                $("#bm_upd_tr").find("input")[i].value=arr[i].innerHTML;
            }
    })
    $("#bm_update_but").click(function () {
        if(isSub($("#bm_upd_tr [type]"))){
            $.ajax({
                url:"/updatePros",
                dateType:"json",
                method:"post",
                data:{
                    id:$("#upd_id").val(),
                    title:$("#upd_title").val(),
                    displayPrice:$("#upd_displayPrice").val(),
                    brind:$("#upd_brind").val(),
                    attrList:$("#upd_attrList").val(),
                    state:$("#upd_state").val(),
                    categoryId:$("#upd_categoryId").val(),
                    pictureId:$("#upd_pictureId").val()
                },
                success:function (data) {
                    if(data.success){
                        window.location.reload();
                    }
                }
            });
        }
    });
    var proProductsId;
    //查看库存
    $(".bm_pros_sto").on("click",function () {
        $("#bm_aboutStock").css("visibility","visible");
        proProductsId= $(this).parent().parent().children(":first").html();
        $.ajax({
            url:"/getProduct",
            dataType:"json",
            data:{
                productsId:proProductsId
            },
            method:"post",
            success:function (data) {
                if(data.success){
                    var tab ="      <tr >\n" +
                        "                       <th>ID</th>\n" +
                        "                        <th>规格索引</th>\n" +
                        "                        <th>规格</th>\n" +
                        "                        <th>库存</th>\n" +
                        "                        <th>价格</th>\n" +
                        "                        <th>商品ID</th>\n" +
                        "                        <th>创建时间</th>\n" +
                        "                        <th>更新时间</th>\n" +
                        "                        <th>操作</th>\n" +
                        "                    </tr>"
                    var context ='';
                    data.data.forEach(item=>{
                        context+='<tr>'+
                            '<td>'+item.id+'</td>'+
                            '<td>'+item.productIndex+'</td>'+
                            '<td title=\''+item.ownSpec+'\'>'+item.ownSpec+'</td>'+
                            '<td>'+item.stock+'</td>'+
                            '<td>'+item.price+'</td>'+
                            '<td>'+item.productsId+'</td>'+
                            '<td title="'+item.createTime+'">'+item.createTime+'</td>'+
                            '<td title="'+item.updateTime+'">'+item.updateTime+'</td>'+
                            '<td><span class="bm_pro_del">删除</span><span class="bm_pro_upd" style="margin-left:10px">修改</span></td>'+
                            '</tr>'
                    })
                    $("#bm_pro_tab").html(tab+context);
                }
            }
        });
    })
    //增加product
    $("#bm_addPro_but").click(function () {
        $("#bm_addPro_div").css("visibility","visible");
        $("#bm_addPro_prosId").val(proProductsId);
    });
    $("#bm_addPro_butt").click(function () {
        if(isSub($("#bm_addPro_tr [type]"))){
            $.ajax({
                url:"/addProduct",
                dataType:"json",
                method:"post",
                data:{
                    productIndex:$("#bm_addPro_index").val(),
                    ownSpec:$("#bm_addPro_spec").val(),
                    stock:$("#bm_addPro_stock").val(),
                    price:$("#bm_addPro_price").val(),
                    productsId:$("#bm_addPro_prosId").val()
                },
                success:function (data) {
                    if(data.success){
                        window.location.reload();
                    }
                }
            });
        }
    });

    //删除product
    $("#bm_pro_tab").on("click",".bm_pro_del",function () {
            var id = $(this).parent().parent().children(":first").html();
            $.ajax({
                url:"/proIsDeleted",
                dataType:"json",
                method:"post",
                data:{
                    id:id
                },
                success:function (data) {
                    if(data.success){
                        window.location.reload();
                    }

                }
            });
    })
var productId ;
    //修改product
    $("#bm_pro_tab").on("click",".bm_pro_upd",function () {
        $("#bm_updPro_div").css("visibility","visible");
        productId = $(this).parent().parent().children(":first").html();

    })
    $("#bm_upd_butt").click(function () {
        if(isSub($("#bm_updPro_tr [type='number']"))){
            $.ajax({
                url:"/updatePro",
                dateType: "json",
                method:"post",
                data:{
                    id:productId,
                    stock:$("#bm_updPro_sto").val(),
                    price:$("#bm_updPro_pri").val()
                },
                success:function (data) {
                    if(data.success){
                        window.location.reload();
                    }
                }
            });
        }
    });
});