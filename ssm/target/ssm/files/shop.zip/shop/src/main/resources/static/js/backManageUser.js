$(function () {
    $("#bm_recover,#bm_logout").on({
        click:function () {
            var isDeleted = $(this).index();
            var id = $(this).parent().parent().children(":first").html();
            $.ajax({
                url: "/updateUserIsDeleted",
                datatype: "json",
                method: "post",
                data: {
                    isDeleted: isDeleted,
                    id: id
                },
                success: function (data) {
                    if (data.success) {
                        window.location.reload();
                    }
                }
            })
        },
        mouseover:function() {
          $(this).css("color","blue");
        },
        mouseout:function () {
            $(this).css("color","black")
        }
    });
})