package com.ling.shop.service;

import com.github.pagehelper.PageInfo;
import com.ling.shop.pojo.dto.ParamCategoryDto;
import com.ling.shop.pojo.po.Cgtype;
import com.ling.shop.pojo.vo.ProductVo;
import com.ling.shop.pojo.vo.ProductsComVo;
import com.ling.shop.pojo.vo.ProductsDataVo;
import com.ling.shop.pojo.vo.ProductsDetailsVo;

import java.util.List;

public interface IProductsService {
        PageInfo<ProductsDataVo> getData(ParamCategoryDto paramCategoryDto);

       ProductsDetailsVo getDetails(String productsId);

       ProductVo getStock(String productIndex, String productsId);

       List<Cgtype> getCategory();
        //根据productsId查询评论
    PageInfo<ProductsComVo> commentByProsId(String productsId,Integer pageNum);
}
