$(function () {
    var uError = false;
    var pError = false;
    var rpError= false;
    var phError = false;
    var coError =false;
    //用户名
    $("#userName").blur(function () {
        uError = false;
        if ($("#userName").val() === "") {
            $("#userName_tip").html("请输入用户名！")
        } else {
            $.ajax({
                url: "/isExist",
                dataType: "json",
                method: "post",
                data: {
                    userName: $("#userName").val(),
                    password: $("#password").val(),
                    phoneNum: $("#phoneNum").val()
                },
                success: function (data) {
                    if (!data.success) {
                        console.log(data);
                        $("#userName_tip").html("用户名已存在！")
                    } else {
                        uError = true;
                        $("#userName_tip").html("")
                    }
                }
            })
        }
    });
    //密码
    $("#password").blur(function () {
        pError = false;
        if ($("#password").val() === "") {
            $("#password_tip").html("请输入密码！")
            $("#rePassword_tip").html("")
        } else {
            $("#password_tip").html("");
            if ($("#rePassword").val() !== "" && $("#password").val() !== $("#rePassword").val()) {
                $("#rePassword_tip").html("密码不一致!")
            } else {
                pError = true;
                $("#rePassword_tip").html("")
            }
        }
    });
    //密码确认
    $("#rePassword").blur(function () {
        rpError = false;
        if ($("#rePassword").val() === "") {
            $("#rePassword_tip").html("请输入密码！")
        } else if ($("#password").val() !== $("#rePassword").val()) {
            $("#rePassword_tip").html("密码不一致!")
        } else {
            $("#rePassword_tip").html("")
            rpError = true;
        }
    });
    //手机号
    $("#phoneNum").blur(function () {
        phError = false;
        if ($("#phoneNum").val() === "") {
            $("#phoneNum_tip").html("请输入手机号！")
        } else if ($("#phoneNum").val().length !== 11) {
            $("#phoneNum_tip").html("请输入11位手机号！")
        } else {
            $("#phoneNum_tip").html("")
            phError=true;
        }
    });
    //注册
   $("#butt").click(function () {
        const list =[uError,pError,rpError,phError,coError];
       console.log(list);
       if(list.findIndex(item=>{return item===false})===-1){
            $.ajax({
                url:"/doRegister",
                datatype:"json",
                method:"post",
                data:{
                    userName:$("#userName").val(),
                    password:$("#password").val(),
                    phoneNum:$("#phoneNum").val()
                },
                success:function (data) {
                    if(data.success){
                        $("#res_box").css({"display":"none"});
                        $("#res_success").css({"display":"block"});
                    }
                }
            })
        }
   })
//去登陆
    $("#res_login").click(function(){
        window.location.href="/login"
    });
    //刷新验证码
    $("#code").click(function () {
        $(this).attr("src","/kaptcha?"+Math.random())
    });
    //判断验证码是否正确
    $("#code_text").blur(function () {
        coError = false;
        $.ajax({
            url:"/codeIsTrue",
            data:{
                verifyCodeActual:$("#code_text").val()
            },
            dataType: "json",
            method:"post",
            success:function (data) {
                if(data.success){
                    $("#code_tip").html("");
                    coError= true;
                }else{
                    $("#code_tip").html("验证码错误！");
                }
            }
        });
    });
});