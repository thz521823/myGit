$(function () {
    //上传图片
    $("#bm_addPic_but").click(function () {
        $("#bm_addPic_div").css("display","block")
    });
        var arr =[];
   $("body").on("change","#bm_addPic_div [type='file']",function () {
       var isTrue = false;
        var rep=/jpeg|png|gif|bmp/ig;
        var str = $(this)[0].files[0].type.split("/")[1];
            if(!rep.test(str)){
                alert("图片格式不正确，请上传 jpeg|png|gif|bmp 格式的图片!");
            }else{
                isTrue = true;
            }
            arr.push(isTrue);

    });
   $("#bm_uploadPic_butt").click(function () {
          var index = arr.findIndex(item=>{
              return item===false
          });
      if(arr.length===4&&index===-1){
       var form = document.getElementById("uploadPicForm");
           var formData = new FormData(form);
       $.ajax({
                url:"/uploadPic",
              method:"post",
              dataType:"json",
              data:formData,
              processData:false,  //告诉jquery不要处理发送的数据
              contentType:false,  //告诉jquery不要设置content-Type请求头
              success:function(data){
                        if(data.success){
                            window.location.reload()
                        }
              }
          });
       }
   });

    //删除图片
    $(".bm_pic_del").on("click",function () {
        var id = $(this).parent().parent().children(":first").html();
        $.ajax({
            url:"/picIsDeleted",
            method:"post",
            dataType: "json",
            data:{
                id:id
            },
            success:function (data) {
                    if(data.success){
                        window.location.reload();
                    }
            }
        });
    })
});