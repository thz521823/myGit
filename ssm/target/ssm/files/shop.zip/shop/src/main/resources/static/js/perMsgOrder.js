$(function () {
    $(".per_ord_sure").on("click",function () {
        var id = $(this).parent().parent().children(":first").html();
        $.ajax({
            url:"/sureGoods",
            dataType:"json",
            data:{
                id:id
            },
            method:"post",
            success:function (data) {
                if(data.success){
                    window.location.reload();
                }
            }
        });
    });
    $(".comment_but").on("click",function () {
            var productsId = $(this).parent().parent().children()[1].innerHTML;
        window.location.href ="/perMsgComment?productsId="+productsId+"&userId="+$("#session").html();
    })
})