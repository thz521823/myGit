package com.ling.shop.pojo.dto;

import lombok.Data;

@Data
public class ParamCategoryDto {
    private String categoryId;
   private String search;
   private String priSort;
   private Integer pageNum;
   private Integer pageSize;
}
