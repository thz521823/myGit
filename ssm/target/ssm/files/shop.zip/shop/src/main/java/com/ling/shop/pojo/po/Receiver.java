package com.ling.shop.pojo.po;

import lombok.Data;

import java.util.Date;

@Data
public class Receiver {
    private Integer id;
    private String address;
    private String recName;
    private String phoneNum;
    private Integer userId;
    private Date createTime;
    private Date updateTime;
    private Integer isDeleted;
}
