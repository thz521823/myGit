$(function () {
    $(".deliver_goods").on("click",function () {
        var id = $(this).parent().parent().children(":first").html();
        var state =$(this).parent().parent().children()[5].innerHTML;

        if(state.indexOf("完成")===-1) {
            $.ajax({
                url: "/deliver",
                dataType: "json",
                data: {
                    id: id
                },
                method: "post",
                success: function (data) {
                    if (data.success) {
                        window.location.reload();
                    }
                }
            });
        }
    })
})