package com.ling.shop.controller;

import com.alibaba.fastjson.JSONObject;
import com.ling.shop.pojo.common.rtn.ReturnData;
import com.ling.shop.pojo.dto.ParamCategoryDto;
import com.ling.shop.pojo.po.Products;
import com.ling.shop.pojo.vo.ProductsDataVo;
import com.ling.shop.service.IPersonalMsgService;
import com.ling.shop.service.IProductsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;
import java.util.Map;

@Controller
public class ProductsController {
    @Autowired
    IProductsService iProductsService;
    @Autowired
    IPersonalMsgService iPersonalMsgService;

    @RequestMapping("/")
    public String getIndex() {
        return "index";
    }


    @RequestMapping("/category")
    public String getCategory(Map<String, Object> map, ParamCategoryDto paramCategoryDto) {
        map.put("queryData", iProductsService.getData(paramCategoryDto));

        return "category";
    }

    @RequestMapping("/productsDetails")
    public String getDetails(Map<String, Object> map, String productsId,Integer pageNum) {
        map.put("proDetails", iProductsService.getDetails(productsId));
        map.put("pageInfo",iProductsService.commentByProsId(productsId,pageNum));
        return "productsDetails";
    }

    @ResponseBody
    @RequestMapping("/getStock")
    public ReturnData<?> getStock(String productIndex, String productsId) {
        return ReturnData.getSuccess(iProductsService.getStock(productIndex, productsId));
    }

    @ResponseBody
    @RequestMapping("/getCategory")
    public ReturnData<?> getCategory() {
        return ReturnData.getSuccess(iProductsService.getCategory());
    }



}