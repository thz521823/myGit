package com.ling.shop.controller;

import com.ling.shop.pojo.common.rtn.ReturnData;
import com.ling.shop.pojo.po.Order;
import com.ling.shop.service.IOrderService;
import com.ling.shop.service.IPersonalMsgService;
import com.ling.shop.util.UUIDGenerator;
import freemarker.core.ReturnInstruction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;

@Controller
public class OrderController {
    @Autowired
    IOrderService iOrderService;
    @Autowired
    IPersonalMsgService iPersonalMsgService;
    //订单页
    @RequestMapping("/order")
    public String getOrder(Map<String,Object>map, String productId, String userId, String number, HttpServletRequest request){
            request.setAttribute("number",Integer.parseInt(number));
        map.put("receivers",iPersonalMsgService.queryAllReceivers(userId));
        map.put("orderProMsg",iOrderService.orderProMsg(productId));
        return "order";
    }
    //生成订单
    @ResponseBody
    @RequestMapping("/addOrder")
    public ReturnData<?> getAddOrder(Order order,String productId){
        order.setOrderNum(UUIDGenerator.generate());
        iOrderService.addOrderAndUpdateStock(order,productId);
        return ReturnData.getSuccess();

    }
}
