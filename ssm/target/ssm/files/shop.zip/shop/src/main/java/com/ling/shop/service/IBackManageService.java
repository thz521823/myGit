package com.ling.shop.service;

import com.github.pagehelper.PageInfo;
import com.ling.shop.pojo.po.*;
import com.ling.shop.pojo.vo.BackOrderVo;
import com.ling.shop.pojo.vo.CommentVo;

import java.util.List;


public interface IBackManageService {
    //查询所有用户
    PageInfo<User> findAllUsers(String prosPageNum);
    //注销，恢复
    boolean updateIsDeleted(String isDeleted,String id);
    //查询所有商品
    PageInfo<Products> getAllpros(String prosPageNum);
    //查询所有分类
    PageInfo<Cgtype> getAllCategory(String catePageNum);
    //增加分类
    int addCategory(String categoryName);
    //删除分类
    int isDeletedCate(String id);
    //查询所有图片
    PageInfo<Picture> getAllpics (String picPageNum);
    //增加商品
    int addPros(Products products);
    //删除商品
    int prosIsDeleted(String id);
    //修改商品
    int updatePros(Products products);
    //获取相关库存
    List<Product> getProduct(String productsId);
    //增加product
    int addProduct (Product product);
    //删除product
    int proIsDeleted(String id);
    //修改product
    int updatePro(Product product);
    //增加图片
    int addPic(Picture picture);
    //删除图片
    int pisIsDeleted(String id);
    //查询所有订单
    PageInfo<BackOrderVo> queryBackAllOrders(Integer pageNum);
    //发货
    int deliverGoods(String id);
    //查询所有评论
    PageInfo<CommentVo> queryBackAllComments(Integer PageNum);
    //删除评论
    int commentIsDeleted (String id);

}
