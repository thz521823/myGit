$(function () {
//提交订单
    $("#order_but").click(function () {
        var receiveId = $("[type='radio']:checked").val();
        var userId = $("#session").html();
        if(receiveId&&userId&&userId!==""){
           $.ajax({
               url:"/addOrder",
               method:"post",
               dataType:"json",
               data:{
                    productsId:$("#productsId").html(),
                    totalPrice:$("#totalPrice").html().substring(1),
                   num:$("#number").html(),
                   receiveId:receiveId,
                   productId:$("#productId").html()
               },
               success:function (data) {
                    if(data.success){
                        $("#successMsg").css("visibility","visible");
                        var delay =parseInt( $("#getTO").html().substring(0,1));
                        console.log(delay);
                        var t = setInterval(function(){
                            if(delay>0){
                                --delay;
                                $("#getTO").html(delay+"s后跳转至首页！")
                            }else{
                                clearInterval(t);
                                window.location.href="/"
                            }
                        },1000)
                    }else{
                        $("#successMsg").css("visibility","visible");
                        $("#successMsg").html('<div><h2>生成订单失败</h2><h2>'+data.msg+'</h2>');
                    }
               }
           });
       }
    });
})